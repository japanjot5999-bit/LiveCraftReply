package com.livecraft.replay;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

final class PathUtil {
    private static final Path DIR = FabricLoader.getInstance().getGameDir().resolve("recordings").resolve("livecraft");
    static void ensureRecordingDir() throws IOException { Files.createDirectories(DIR); }
    static Path newOutputPath() {
        String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
        return DIR.resolve("LiveCraft_" + stamp + ".mp4");
    }
    private PathUtil() {}
}
