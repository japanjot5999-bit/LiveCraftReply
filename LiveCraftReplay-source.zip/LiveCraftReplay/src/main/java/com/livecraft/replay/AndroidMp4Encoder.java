package com.livecraft.replay;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.file.Path;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Reflection-based Android MediaCodec AVC encoder. Reflection keeps android.jar out of the
 * Fabric build classpath; Android classes are resolved at runtime on Android-based launchers.
 * Uses flexible YUV420 Image input and an MP4 MediaMuxer output.
 */
final class AndroidMp4Encoder {
    private static final String MIME = "video/avc";
    private static final int COLOR_FORMAT_YUV420_FLEXIBLE = 0x7F420888;
    private static final int CONFIGURE_FLAG_ENCODE = 1;
    private static final int BUFFER_FLAG_END_OF_STREAM = 4;
    private static final int INFO_TRY_AGAIN_LATER = -1;
    private static final int INFO_OUTPUT_FORMAT_CHANGED = -2;

    private final Path output;
    private final int width, height, fps, bitrateMbps;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final CountDownLatch stopped = new CountDownLatch(1);
    private Thread worker;
    private volatile Throwable failure;

    private Object codec, muxer, bufferInfo;
    private Method dequeueInputBuffer, getInputImage, queueInputBuffer, dequeueOutputBuffer,
        getOutputFormat, getOutputBuffer, releaseOutputBuffer, signalEndOfInputStream, stopCodec,
        releaseCodec, addTrack, startMuxer, writeSampleData, stopMuxer, releaseMuxer;
    private int muxerTrack = -1;
    private boolean muxerStarted;
    private long frameNumber;

    AndroidMp4Encoder(Path output, int width, int height, int fps, int bitrateMbps) {
        this.output = output;
        this.width = width;
        this.height = height;
        this.fps = fps;
        this.bitrateMbps = bitrateMbps;
    }

    void start() throws Exception {
        Class<?> codecClass = Class.forName("android.media.MediaCodec");
        Class<?> formatClass = Class.forName("android.media.MediaFormat");
        Class<?> muxerClass = Class.forName("android.media.MediaMuxer");
        Class<?> bufferInfoClass = Class.forName("android.media.MediaCodec$BufferInfo");

        Method createEncoder = codecClass.getMethod("createEncoderByType", String.class);
        Method createVideoFormat = formatClass.getMethod("createVideoFormat", String.class, int.class, int.class);
        codec = createEncoder.invoke(null, MIME);
        Object format = createVideoFormat.invoke(null, MIME, width, height);
        call(format, "setInteger", new Class<?>[]{String.class, int.class}, "color-format", COLOR_FORMAT_YUV420_FLEXIBLE);
        call(format, "setInteger", new Class<?>[]{String.class, int.class}, "bitrate", bitrateMbps * 1_000_000);
        call(format, "setInteger", new Class<?>[]{String.class, int.class}, "frame-rate", fps);
        call(format, "setInteger", new Class<?>[]{String.class, int.class}, "i-frame-interval", 2);

        Method configure = codecClass.getMethod("configure", formatClass, Class.forName("android.view.Surface"),
            Class.forName("android.media.MediaCrypto"), int.class);
        configure.invoke(codec, format, null, null, CONFIGURE_FLAG_ENCODE);
        codecClass.getMethod("start").invoke(codec);

        Constructor<?> muxerCtor = muxerClass.getConstructor(String.class, int.class);
        muxer = muxerCtor.newInstance(output.toAbsolutePath().toString(), 0 /* MPEG_4 */);
        bufferInfo = bufferInfoClass.getConstructor().newInstance();

        dequeueInputBuffer = codecClass.getMethod("dequeueInputBuffer", long.class);
        getInputImage = codecClass.getMethod("getInputImage", int.class);
        queueInputBuffer = codecClass.getMethod("queueInputBuffer", int.class, int.class, int.class, long.class, int.class);
        dequeueOutputBuffer = codecClass.getMethod("dequeueOutputBuffer", bufferInfoClass, long.class);
        getOutputFormat = codecClass.getMethod("getOutputFormat");
        getOutputBuffer = codecClass.getMethod("getOutputBuffer", int.class);
        releaseOutputBuffer = codecClass.getMethod("releaseOutputBuffer", int.class, boolean.class);
        stopCodec = codecClass.getMethod("stop");
        releaseCodec = codecClass.getMethod("release");
        addTrack = muxerClass.getMethod("addTrack", formatClass);
        startMuxer = muxerClass.getMethod("start");
        writeSampleData = muxerClass.getMethod("writeSampleData", int.class, ByteBuffer.class, bufferInfoClass);
        stopMuxer = muxerClass.getMethod("stop");
        releaseMuxer = muxerClass.getMethod("release");

        running.set(true);
        worker = new Thread(this::runEncoder, "LiveCraft-MediaCodec");
        worker.setDaemon(true);
        worker.start();
    }

    boolean isRunning() { return running.get(); }

    void finish() {
        // The worker polls with a short timeout; do not interrupt it, because interruption
        // would bypass encoder EOS and leave the MP4 container unfinished.
        running.set(false);
    }

    void awaitStopped(long millis) throws InterruptedException { stopped.await(millis, TimeUnit.MILLISECONDS); }

    private void runEncoder() {
        try {
            while (running.get() || !queueEmpty()) {
                RecorderController.Frame frame = RecorderController.takeFrame(15);
                if (frame != null) submitFrame(frame);
                drain(false);
            }
            sendEos();
            long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(5);
            while (System.nanoTime() < deadline && !drain(true)) { /* finish muxer */ }
        } catch (Throwable t) {
            failure = t;
            LiveCraftReplay.LOGGER.error("LiveCraft encoder failed", t);
        } finally {
            running.set(false);
            cleanup();
            stopped.countDown();
        }
    }

    private boolean queueEmpty() {
        return RecorderController.frameQueueIsEmpty();
    }

    private void submitFrame(RecorderController.Frame frame) throws Exception {
        int index = (Integer) dequeueInputBuffer.invoke(codec, 0L);
        if (index < 0) return; // Encoder is busy: drop rather than block the game.
        Object image = getInputImage.invoke(codec, index);
        if (image == null) {
            queueInputBuffer.invoke(codec, index, 0, 0, ptsUs(), 0);
            return;
        }
        try {
            writeYuv420Image(image, frame);
            int bytes = width * height * 3 / 2;
            queueInputBuffer.invoke(codec, index, 0, bytes, ptsUs(), 0);
            frameNumber++;
        } finally {
            call(image, "close", new Class<?>[0]);
        }
    }

    private long ptsUs() { return frameNumber * 1_000_000L / fps; }

    private void writeYuv420Image(Object image, RecorderController.Frame frame) throws Exception {
        Object planes = call(image, "getPlanes", new Class<?>[0]);
        Object yPlane = Array.get(planes, 0);
        Object uPlane = Array.get(planes, 1);
        Object vPlane = Array.get(planes, 2);
        ByteBuffer yBuf = (ByteBuffer) call(yPlane, "getBuffer", new Class<?>[0]);
        ByteBuffer uBuf = (ByteBuffer) call(uPlane, "getBuffer", new Class<?>[0]);
        ByteBuffer vBuf = (ByteBuffer) call(vPlane, "getBuffer", new Class<?>[0]);
        int yRow = (Integer) call(yPlane, "getRowStride", new Class<?>[0]);
        int yPixel = (Integer) call(yPlane, "getPixelStride", new Class<?>[0]);
        int uRow = (Integer) call(uPlane, "getRowStride", new Class<?>[0]);
        int uPixel = (Integer) call(uPlane, "getPixelStride", new Class<?>[0]);
        int vRow = (Integer) call(vPlane, "getRowStride", new Class<?>[0]);
        int vPixel = (Integer) call(vPlane, "getPixelStride", new Class<?>[0]);
        byte[] rgba = frame.rgbaBottomUp();
        int sw = frame.width(), sh = frame.height();

        // Convert and scale directly into the three Image planes. RGBA is OpenGL bottom-up.
        for (int y = 0; y < height; y++) {
            int sy = sh - 1 - Math.min(sh - 1, (int) ((long) y * sh / height));
            for (int x = 0; x < width; x++) {
                int sx = Math.min(sw - 1, (int) ((long) x * sw / width));
                int p = (sy * sw + sx) * 4;
                int r = rgba[p] & 255, g = rgba[p + 1] & 255, b = rgba[p + 2] & 255;
                int yy = clamp(((66 * r + 129 * g + 25 * b + 128) >> 8) + 16);
                yBuf.put(y * yRow + x * yPixel, (byte) yy);
            }
        }
        for (int y = 0; y < height; y += 2) {
            int sy0 = sh - 1 - Math.min(sh - 1, (int) ((long) y * sh / height));
            int sy1 = sh - 1 - Math.min(sh - 1, (int) ((long) Math.min(height - 1, y + 1) * sh / height));
            for (int x = 0; x < width; x += 2) {
                int sx0 = Math.min(sw - 1, (int) ((long) x * sw / width));
                int sx1 = Math.min(sw - 1, (int) ((long) Math.min(width - 1, x + 1) * sw / width));
                int p0 = (sy0 * sw + sx0) * 4;
                int p1 = (sy0 * sw + sx1) * 4;
                int p2 = (sy1 * sw + sx0) * 4;
                int p3 = (sy1 * sw + sx1) * 4;
                int r = ((rgba[p0] & 255) + (rgba[p1] & 255) + (rgba[p2] & 255) + (rgba[p3] & 255)) >> 2;
                int g = ((rgba[p0 + 1] & 255) + (rgba[p1 + 1] & 255) + (rgba[p2 + 1] & 255) + (rgba[p3 + 1] & 255)) >> 2;
                int bl = ((rgba[p0 + 2] & 255) + (rgba[p1 + 2] & 255) + (rgba[p2 + 2] & 255) + (rgba[p3 + 2] & 255)) >> 2;
                int u = clamp(((-38 * r - 74 * g + 112 * bl + 128) >> 8) + 128);
                int v = clamp(((112 * r - 94 * g - 18 * bl + 128) >> 8) + 128);
                int ci = (y / 2) * uRow + (x / 2) * uPixel;
                uBuf.put(ci, (byte) u);
                int vi = (y / 2) * vRow + (x / 2) * vPixel;
                vBuf.put(vi, (byte) v);
            }
        }
    }

    private static int clamp(int value) { return Math.max(0, Math.min(255, value)); }

    private boolean drain(boolean wait) throws Exception {
        boolean eos = false;
        int timeout = wait ? 10_000 : 0;
        while (true) {
            int index = (Integer) dequeueOutputBuffer.invoke(codec, bufferInfo, (long) timeout);
            if (index == INFO_TRY_AGAIN_LATER) return eos;
            if (index == INFO_OUTPUT_FORMAT_CHANGED) {
                Object format = getOutputFormat.invoke(codec);
                muxerTrack = (Integer) addTrack.invoke(muxer, format);
                startMuxer.invoke(muxer);
                muxerStarted = true;
                continue;
            }
            if (index >= 0) {
                ByteBuffer data = (ByteBuffer) getOutputBuffer.invoke(codec, index);
                int offset = getInt(bufferInfo, "offset");
                int size = getInt(bufferInfo, "size");
                int flags = getInt(bufferInfo, "flags");
                if (data != null && size > 0 && muxerStarted) {
                    data.position(offset);
                    data.limit(offset + size);
                    writeSampleData.invoke(muxer, muxerTrack, data, bufferInfo);
                }
                releaseOutputBuffer.invoke(codec, index, false);
                if ((flags & BUFFER_FLAG_END_OF_STREAM) != 0) {
                    eos = true;
                    return true;
                }
            }
        }
    }

    private void sendEos() {
        try {
            int index = (Integer) dequeueInputBuffer.invoke(codec, 10_000L);
            if (index >= 0) queueInputBuffer.invoke(codec, index, 0, 0, ptsUs(), BUFFER_FLAG_END_OF_STREAM);
        } catch (Throwable t) {
            LiveCraftReplay.LOGGER.warn("Could not send encoder EOS marker", t);
        }
    }

    private void cleanup() {
        try { if (codec != null) stopCodec.invoke(codec); } catch (Throwable ignored) {}
        try { if (codec != null) releaseCodec.invoke(codec); } catch (Throwable ignored) {}
        try { if (muxer != null && muxerStarted) stopMuxer.invoke(muxer); } catch (Throwable ignored) {}
        try { if (muxer != null) releaseMuxer.invoke(muxer); } catch (Throwable ignored) {}
        if (failure != null) LiveCraftReplay.LOGGER.error("MP4 may be incomplete; encoder failure occurred.", failure);
        else LiveCraftReplay.LOGGER.info("MP4 finalized: {}", output);
        RecorderController.clearQueue();
    }

    private static Object call(Object target, String name, Class<?>[] types, Object... args) throws Exception {
        Method m = target.getClass().getMethod(name, types);
        return m.invoke(target, args);
    }
    private static int getInt(Object target, String field) throws Exception {
        Field f = target.getClass().getField(field);
        return f.getInt(target);
    }
}
