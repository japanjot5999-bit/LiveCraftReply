package com.livecraft.replay;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

final class RecorderConfig {
    static final int OUTPUT_WIDTH = 2560;
    static final int OUTPUT_HEIGHT = 1440;
    static final int FPS = 60;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("livecraft-replay.json");

    static int bitrateMbps = 24;
    static boolean autoStart = true;
    static boolean keepPartialOnError = true;

    static void load() {
        if (!Files.exists(FILE)) {
            save();
            return;
        }
        try {
            Settings s = GSON.fromJson(Files.readString(FILE), Settings.class);
            if (s != null) {
                bitrateMbps = Math.max(5, Math.min(60, s.bitrateMbps));
                autoStart = s.autoStart;
                keepPartialOnError = s.keepPartialOnError;
            }
        } catch (Exception e) {
            LiveCraftReplay.LOGGER.error("Could not read config; defaults will be used", e);
        }
    }

    static void setBitrateMbps(int value) {
        bitrateMbps = Math.max(5, Math.min(60, value));
        save();
    }

    static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(new Settings(bitrateMbps, autoStart, keepPartialOnError)));
        } catch (IOException e) {
            LiveCraftReplay.LOGGER.error("Could not save config", e);
        }
    }

    private record Settings(int bitrateMbps, boolean autoStart, boolean keepPartialOnError) {}
    private RecorderConfig() {}
}
