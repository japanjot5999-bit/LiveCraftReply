package com.livecraft.replay;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public final class LiveCraftReplayClient implements ClientModInitializer {
    private static KeyMapping recordKey;
    private static KeyMapping pauseKey;
    private static KeyMapping stopKey;

    @Override
    public void onInitializeClient() {
        RecorderConfig.load();

        recordKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.livecraft_replay.record", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_F8,
            "category.livecraft_replay"));
        pauseKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.livecraft_replay.pause", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_F7,
            "category.livecraft_replay"));
        stopKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.livecraft_replay.stop", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_F9,
            "category.livecraft_replay"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (recordKey.consumeClick()) {
                if (!RecorderController.isRecording()) RecorderController.start();
                else client.gui.setOverlayMessage(Component.literal("LiveCraft is already recording"), false);
            }
            while (pauseKey.consumeClick()) {
                if (RecorderController.isRecording()) {
                    RecorderController.togglePause();
                    client.gui.setOverlayMessage(Component.literal(RecorderController.isPaused()
                        ? "LiveCraft recording paused" : "LiveCraft recording resumed"), false);
                }
            }
            while (stopKey.consumeClick()) {
                if (RecorderController.isRecording()) {
                    RecorderController.stop("stop key");
                    client.gui.setOverlayMessage(Component.literal("LiveCraft: saving MP4"), false);
                }
            }
        });

        // Start a new MP4 automatically after joining a playable world/server.
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            if (RecorderConfig.autoStart) {
                client.execute(() -> {
                    boolean ok = RecorderController.start();
                    client.gui.setOverlayMessage(Component.literal(ok
                        ? "LiveCraft: recording started" : "LiveCraft: recording could not start; see latest.log"), false);
                });
            }
        });

        HudRenderCallback.EVENT.register((graphics, tickCounter) -> {
            if (!RecorderController.isRecording()) return;
            String label = RecorderController.isPaused() ? "LCR  PAUSED" : "LCR  ● REC";
            int color = RecorderController.isPaused() ? 0xFFFFC04D : 0xFFFF5555;
            graphics.drawString(net.minecraft.client.Minecraft.getInstance().font, label, 8, 8, color, true);
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(literal("lcr")
                .then(literal("start").executes(context -> {
                    boolean ok = RecorderController.start();
                    context.getSource().sendFeedback(Component.literal(ok
                        ? "LiveCraft: recording started (MP4, hardware encoder)."
                        : "LiveCraft: could not start. Check latest.log for the reason."));
                    return ok ? 1 : 0;
                }))
                .then(literal("stop").executes(context -> {
                    RecorderController.stop("manual stop");
                    context.getSource().sendFeedback(Component.literal("LiveCraft: stopping and finalizing MP4..."));
                    return 1;
                }))
                .then(literal("pause").executes(context -> {
                    RecorderController.togglePause();
                    context.getSource().sendFeedback(Component.literal(RecorderController.status()));
                    return 1;
                }))
                .then(literal("status").executes(context -> {
                    context.getSource().sendFeedback(Component.literal(RecorderController.status()));
                    return 1;
                }))
                .then(literal("bitrate").then(argument("mbps", IntegerArgumentType.integer(5, 60))
                    .executes(context -> {
                        int mbps = IntegerArgumentType.getInteger(context, "mbps");
                        RecorderConfig.setBitrateMbps(mbps);
                        context.getSource().sendFeedback(Component.literal("LiveCraft: bitrate set to " + mbps + " Mbps. Applies next recording."));
                        return 1;
                    })))
            )
        );

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) ->
            RecorderController.stop("world disconnected"));
        ClientLifecycleEvents.CLIENT_STOPPING.register(client ->
            RecorderController.stopAndWait("Minecraft is closing", 4500));
    }
}
