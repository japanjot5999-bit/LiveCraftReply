package com.livecraft.replay;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.network.chat.Component;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public final class LiveCraftReplayClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        RecorderConfig.load();
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(literal("lcr")
                .then(literal("start").executes(context -> {
                    boolean ok = RecorderController.start();
                    context.getSource().sendFeedback(Component.literal(ok
                        ? "LiveCraft: recording started (MP4, hardware encoder)."
                        : "LiveCraft: could not start. Check latest.log for the reason."));
                    return ok ? 1 : 0;
                }))
                .then(literal("stop").executes(context -> {
                    RecorderController.stop("manual stop");
                    context.getSource().sendFeedback(Component.literal("LiveCraft: stopping and finalizing MP4..."));
                    return 1;
                }))
                .then(literal("status").executes(context -> {
                    context.getSource().sendFeedback(Component.literal(RecorderController.status()));
                    return 1;
                }))
                .then(literal("bitrate").then(argument("mbps", IntegerArgumentType.integer(5, 60))
                    .executes(context -> {
                        int mbps = IntegerArgumentType.getInteger(context, "mbps");
                        RecorderConfig.setBitrateMbps(mbps);
                        context.getSource().sendFeedback(Component.literal("LiveCraft: bitrate set to " + mbps + " Mbps. Applies next recording."));
                        return 1;
                    })))
            )
        );

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) ->
            RecorderController.stop("world disconnected"));
        ClientLifecycleEvents.CLIENT_STOPPING.register(client ->
            RecorderController.stopAndWait("Minecraft is closing", 4500));
    }
}
