package com.livecraft.replay.mixin;

import com.livecraft.replay.RecorderController;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Captures after Minecraft has completed the frame, including the HUD, just before buffer swap. */
@Mixin(Minecraft.class)
public abstract class MinecraftMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void livecraft$afterFrame(boolean tick, CallbackInfo ci) {
        RecorderController.captureFrame();
    }
}
