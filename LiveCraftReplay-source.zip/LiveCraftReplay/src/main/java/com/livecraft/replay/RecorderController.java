package com.livecraft.replay;

import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL32;

import java.nio.ByteBuffer;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/** Render-thread capture using a small PBO ring; encoding is delegated to a worker. */
public final class RecorderController {
    private static final int SLOT_COUNT = 3;
    private static final int GL_PIXEL_PACK_BUFFER = 0x88EB;
    private static final int GL_STREAM_READ = 0x88E1;
    private static final int GL_MAP_READ_BIT = 0x0001;
    private static final int GL_SYNC_GPU_COMMANDS_COMPLETE = 0x9117;
    private static final int GL_ALREADY_SIGNALED = 0x911A;
    private static final int GL_CONDITION_SATISFIED = 0x911C;

    private static final AtomicBoolean STARTING_OR_RECORDING = new AtomicBoolean(false);
    private static final ArrayBlockingQueue<Frame> FRAME_QUEUE = new ArrayBlockingQueue<>(2);
    private static AndroidMp4Encoder encoder;
    private static int[] pbos = new int[0];
    private static long[] fences = new long[0];
    private static int captureWidth;
    private static int captureHeight;
    private static boolean warnedPbo;
    private static volatile boolean paused;
    private static long capturedFrames;
    private static long droppedFrames;
    private static long lastFpsReportNs;

    public static synchronized boolean start() {
        if (STARTING_OR_RECORDING.get()) return true;
        try {
            PathUtil.ensureRecordingDir();
            encoder = new AndroidMp4Encoder(PathUtil.newOutputPath(), RecorderConfig.OUTPUT_WIDTH,
                RecorderConfig.OUTPUT_HEIGHT, RecorderConfig.FPS, RecorderConfig.bitrateMbps);
            encoder.start();
            STARTING_OR_RECORDING.set(true);
            paused = false;
            capturedFrames = 0;
            droppedFrames = 0;
            LiveCraftReplay.LOGGER.info("Recording started: 2560x1440 @ 60 fps; hardware AVC requested.");
            return true;
        } catch (Throwable t) {
            STARTING_OR_RECORDING.set(false);
            LiveCraftReplay.LOGGER.error("Could not start LiveCraft MP4 recording. Android MediaCodec may be unavailable or may reject 1440p60.", t);
            return false;
        }
    }

    public static void captureFrame() {
        if (!STARTING_OR_RECORDING.get() || paused || encoder == null || !encoder.isRunning()) return;
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc == null || mc.getWindow() == null) return;
            int width = mc.getWindow().getWidth();
            int height = mc.getWindow().getHeight();
            if (width <= 0 || height <= 0) return;
            if (pbos.length == 0 || width != captureWidth || height != captureHeight) initPbos(width, height);
            pollCompletedPbos();
            int free = findFreePbo();
            if (free < 0) {
                droppedFrames++;
                return;
            }
            GL15.glBindBuffer(GL_PIXEL_PACK_BUFFER, pbos[free]);
            GL11.glPixelStorei(GL11.GL_PACK_ALIGNMENT, 1);
            // Minecraft's render(boolean) tail runs after the main target has been blitted.
            // Read from the completed back buffer before the window swaps it to the display.
            GL11.glReadBuffer(GL11.GL_BACK);
            GL11.glReadPixels(0, 0, width, height, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, 0L);
            fences[free] = GL32.glFenceSync(GL_SYNC_GPU_COMMANDS_COMPLETE, 0);
            GL15.glBindBuffer(GL_PIXEL_PACK_BUFFER, 0);
            capturedFrames++;
            reportStats();
        } catch (Throwable t) {
            if (!warnedPbo) {
                warnedPbo = true;
                LiveCraftReplay.LOGGER.error("GPU frame capture failed. Recording will stop to avoid corrupt output.", t);
            }
            stop("GPU frame capture error");
        }
    }

    private static void initPbos(int width, int height) {
        deletePbos();
        captureWidth = width;
        captureHeight = height;
        pbos = new int[SLOT_COUNT];
        fences = new long[SLOT_COUNT];
        for (int i = 0; i < pbos.length; i++) {
            pbos[i] = GL15.glGenBuffers();
            GL15.glBindBuffer(GL_PIXEL_PACK_BUFFER, pbos[i]);
            GL15.glBufferData(GL_PIXEL_PACK_BUFFER, (long) width * height * 4L, GL_STREAM_READ);
        }
        GL15.glBindBuffer(GL_PIXEL_PACK_BUFFER, 0);
        LiveCraftReplay.LOGGER.info("Capture framebuffer is {}x{}; output is fixed at 2560x1440.", width, height);
    }

    private static void pollCompletedPbos() {
        for (int i = 0; i < fences.length; i++) {
            long fence = fences[i];
            if (fence == 0L) continue;
            int state = GL32.glClientWaitSync(fence, 0, 0L);
            if (state != GL_ALREADY_SIGNALED && state != GL_CONDITION_SATISFIED) continue;
            GL15.glBindBuffer(GL_PIXEL_PACK_BUFFER, pbos[i]);
            ByteBuffer mapped = GL30.glMapBufferRange(GL_PIXEL_PACK_BUFFER, 0L,
                (long) captureWidth * captureHeight * 4L, GL_MAP_READ_BIT, null);
            if (mapped != null) {
                byte[] copy = new byte[captureWidth * captureHeight * 4];
                mapped.get(copy);
                GL15.glUnmapBuffer(GL_PIXEL_PACK_BUFFER);
                if (!FRAME_QUEUE.offer(new Frame(copy, captureWidth, captureHeight, System.nanoTime()))) {
                    droppedFrames++;
                }
            } else {
                droppedFrames++;
            }
            GL15.glBindBuffer(GL_PIXEL_PACK_BUFFER, 0);
            GL32.glDeleteSync(fence);
            fences[i] = 0L;
        }
    }

    private static int findFreePbo() {
        for (int i = 0; i < fences.length; i++) if (fences[i] == 0L) return i;
        return -1;
    }

    private static void reportStats() {
        long now = System.nanoTime();
        if (now - lastFpsReportNs > TimeUnit.SECONDS.toNanos(10)) {
            lastFpsReportNs = now;
            LiveCraftReplay.LOGGER.info("LiveCraft capture: {} frames queued, {} dropped (encoder may be behind).", capturedFrames, droppedFrames);
        }
    }

    public static synchronized void stop(String reason) {
        if (!STARTING_OR_RECORDING.getAndSet(false)) return;
        LiveCraftReplay.LOGGER.info("Stopping recorder: {}", reason);
        finishStop();
    }

    public static synchronized void stopAndWait(String reason, long timeoutMs) {
        if (!STARTING_OR_RECORDING.getAndSet(false)) return;
        LiveCraftReplay.LOGGER.info("Stopping recorder before shutdown: {}", reason);
        finishStop();
        if (encoder != null) {
            try { encoder.awaitStopped(timeoutMs); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
    }

    private static void finishStop() {
        try {
            // Wait only during stop, never during gameplay, so pending GPU readbacks can be drained.
            GL11.glFinish();
            pollCompletedPbos();
        } catch (Throwable t) {
            LiveCraftReplay.LOGGER.warn("Could not drain the final GPU capture buffers", t);
        }
        try {
            deletePbos();
        } catch (Throwable t) {
            LiveCraftReplay.LOGGER.warn("Could not release GPU capture buffers during shutdown", t);
        }
        AndroidMp4Encoder current = encoder;
        encoder = null;
        if (current != null) current.finish();
    }

    private static void deletePbos() {
        if (pbos.length > 0) {
            for (long fence : fences) if (fence != 0L) GL32.glDeleteSync(fence);
            for (int pbo : pbos) GL15.glDeleteBuffers(pbo);
        }
        pbos = new int[0];
        fences = new long[0];
        captureWidth = captureHeight = 0;
    }

    public static synchronized void togglePause() {
        if (STARTING_OR_RECORDING.get()) paused = !paused;
    }

    public static boolean isRecording() { return STARTING_OR_RECORDING.get(); }
    public static boolean isPaused() { return paused; }
    public static long capturedFrames() { return capturedFrames; }
    public static long droppedFrames() { return droppedFrames; }

    public static String status() {
        if (!STARTING_OR_RECORDING.get()) return "LiveCraft: not recording. Use /lcr start.";
        return "LiveCraft: " + (paused ? "paused" : "recording") + " 1440p60 MP4; captured=" + capturedFrames + ", dropped=" + droppedFrames + ".";
    }

    static Frame takeFrame(long timeoutMs) throws InterruptedException {
        return FRAME_QUEUE.poll(timeoutMs, TimeUnit.MILLISECONDS);
    }

    static void clearQueue() { FRAME_QUEUE.clear(); }
    static boolean frameQueueIsEmpty() { return FRAME_QUEUE.isEmpty(); }

    record Frame(byte[] rgbaBottomUp, int width, int height, long captureNs) {}

    private RecorderController() {}
}
