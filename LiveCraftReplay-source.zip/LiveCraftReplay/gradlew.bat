@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle 9.2.1 is not installed. Install Gradle 9.2.1, then run gradle build.
exit /b 1
