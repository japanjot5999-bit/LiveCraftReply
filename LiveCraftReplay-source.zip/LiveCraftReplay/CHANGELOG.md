# Changelog

## 0.1.0-alpha
- Initial Android-first Fabric 1.21.11 source project.
- Live H.264 MP4 pipeline using Android MediaCodec + MediaMuxer.
- PBO-based frame capture queue and recording commands.
- Automatic finalization request when leaving a world or closing Minecraft.
- 1440p60 target profile with configurable bitrate.
