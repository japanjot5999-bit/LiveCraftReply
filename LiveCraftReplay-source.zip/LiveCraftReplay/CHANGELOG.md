# Changelog

## 0.2.0 — Feature scope recorded (not a completed implementation)
- Added the full LiveCraft Replay feature specification and staged development plan.
- Confirmed no artificial maximum recording-duration limit.
- Set planned defaults: auto-start on world join, optional microphone off by default, optional cloud backup off by default.
- Clarified that live MP4 and genuine `.mcpr` replay capture are separate systems.
- No new runtime features are claimed in this planning update.

## 0.1.0-alpha
- Initial experimental live MP4 capture source and basic `/lcr` commands.

## 0.2.0-alpha (development)
- Added automatic MP4 recording when joining a world (enabled by default for fresh configs).
- Added F8 start, F7 pause/resume, and F9 stop keybindings.
- Added an on-screen recording/paused indicator.
- Added `/lcr pause` command and status reporting for pause state.
- MP4 recordings continue to be saved under `recordings/livecraft/`.

This is an early implementation and must be compiled and tested on the target Android launcher. It does not yet implement a clickable pause-menu button, media-library screen, `.mcpr` replay capture, audio capture, or crash-recovery system.
