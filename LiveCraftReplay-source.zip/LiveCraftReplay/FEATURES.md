# LiveCraft Replay — Full Feature Specification

Target: Minecraft Java 1.21.11, Fabric, Android-first (MJLauncher). This document is the agreed product scope; it is **not** a claim that every feature is implemented in the current alpha.

## Product rules
- No artificial maximum recording-duration limit. Available storage, filesystem limits, device thermals, and encoder stability still apply.
- MP4 is captured live during gameplay; it is not created by exporting a replay afterward.
- `.mcpr` replay capture is a separate system and must never be represented by renaming an MP4.
- 1440p (2560×1440) at 60 FPS is the requested target, not a guaranteed device capability. Detect unsupported encoder configurations and report actual output settings honestly.
- Prefer Android hardware encoding, bounded queues, frame dropping under pressure, and no blocking work on Minecraft's render thread.
- Do not silently claim zero performance impact. Show warnings for encoder load, dropped frames, heat, and low storage where measurable.

## Agreed defaults
- Auto-start when entering a world: ON by default, user-configurable to manual-only or either mode.
- Microphone: optional and OFF by default; request permission only when enabled.
- Cloud backup: optional and OFF by default; local storage remains the default.
- Local recording folder: `recordings/LiveCraft/` under the Minecraft game directory where writable; provide a configurable folder and explain Android storage restrictions.
- No recording-duration cap.

## Feature scope

### Live MP4 capture
- Start automatically on world join, or manually from the in-game UI.
- Persistent, visible recording indicator with elapsed time, resolution, FPS, bitrate, and dropped-frame count when available.
- Touch-friendly controls: start, pause, resume, stop, and snapshot.
- Pause/resume without producing misleading timestamps; stop finalizes the MP4.
- Optional pre-record countdown.
- H.264 baseline support; HEVC only when the Android device exposes a compatible encoder.
- Resolution presets: 480p, 720p, 1080p, 1440p; custom settings where supported.
- FPS presets: 24, 30, 45, 60; only offer modes supported by the encoder and capture pipeline.
- Adjustable bitrate (target range 4–40 Mbps), with file-size estimate.
- Hardware capability detection and clear error messages instead of silent fallback.
- Thermal/performance warning and optional quality adaptation; adaptation must be visible and configurable.
- Audio: Minecraft/game audio where supported by the platform/launcher integration; optional microphone capture, off by default, with explicit Android permission. Separate volume controls when both tracks are available.

### Saving and recovery
- Finalize MP4 automatically when leaving a world or normally closing Minecraft.
- Write to a temporary/in-progress file and finalize/rename only after muxer completion.
- Best-effort recovery metadata for interrupted sessions; explain that abrupt power loss or force-stop can still damage the latest MP4.
- Auto-split long recordings into sequential files if needed for reliability, but do not impose a total recording-duration limit.
- Warn on low storage; never silently delete user recordings.
- Automatic names containing world name and date/time, with collision-safe filenames.
- Recording history and metadata: duration, resolution, FPS, bitrate, file size, date, world/session name.
- User-configurable backup folder and optional Google Drive backup only after the user connects/authorizes it.

### In-game interface and library
- Touchscreen-friendly recording widget and pause-menu entry.
- Settings screen for auto-start/manual mode, video quality, audio, storage, backup, and overlay options.
- Library with thumbnails, playback/open-in-phone-player, search, sorting, rename, and delete confirmation.
- Bookmarks/markers during recording and a list of marked timestamps.
- Snapshot capture and optional HUD-free/cinematic screenshot mode.
- Keyboard shortcuts where available, without requiring a mouse on touch devices.
- Optional compact overlay showing recording state and diagnostics.

### Replay data system (separate from MP4)
- Genuine replay data files with `.mcpr` compatibility only if implemented against the appropriate replay format/protocol.
- Replay viewer, timeline seeking, playback speed, first-/third-person view, free camera, camera paths, and bookmarks.
- Do not claim ReplayMod compatibility until tested against the target replay format and version.

### Advanced tools
- Cinematic mode to hide HUD and optional overlays.
- Audio mixer for available game and microphone tracks.
- Recording metadata and session history.
- Local backup/copy tools and optional cloud backup.
- Storage manager and configurable cleanup suggestions; never auto-delete without user consent.
- Crash recovery where technically possible.

## Development milestones
1. Verify and stabilize the live MP4 pipeline on Android; test actual encoder capabilities and output playback.
2. Add automatic world-join recording, visible status, pause/resume/stop UI, and robust finalization.
3. Add settings, library, file metadata, thumbnails, search, sorting, rename/delete, and snapshots.
4. Add audio capture and microphone permission flow, subject to MJLauncher/Android support.
5. Add recovery, bookmarks, splitting, storage warnings, and optional backup integration.
6. Build the independent replay-data capture/viewer system and validate real `.mcpr` compatibility.
7. Add cinematic camera tools and advanced editor features.

## Current alpha status
The existing source alpha is only a prototype. It has basic `/lcr` commands and an experimental Android MediaCodec video path. The following are not yet implemented or verified: automatic start, pause/resume UI, recording library, audio, `.mcpr` replay capture/viewer, camera editor, cloud backup, thumbnails, and device-level 1440p60. A successful cloud compilation is not proof of runtime correctness. Each milestone requires a successful build and real MJLauncher testing.
