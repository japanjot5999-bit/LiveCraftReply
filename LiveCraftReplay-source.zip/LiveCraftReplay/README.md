# LiveCraft Replay — Fabric 1.21.11 (Android-first prototype)

This is a **source project**, not a ready-tested release JAR. It targets Minecraft Java 1.21.11, Fabric Loader 0.18.1, Fabric API 0.141.1+1.21.11 and Java 21.

## Current implementation

- Client mod entrypoint and `/lcr start`, `/lcr stop`, `/lcr status`, `/lcr bitrate <5..60>` commands.
- Render hook after `Minecraft.render(boolean)`, intended to read the completed back buffer before swap.
- Three-slot OpenGL Pixel Buffer Object (PBO) ring to avoid waiting synchronously for GPU readback. Busy encoder queues cause frame drops rather than blocking the render thread.
- Android `MediaCodec` AVC hardware encoder accessed through reflection, plus `MediaMuxer` MP4 output.
- Target output: **2560×1440, 60 FPS**, default 24 Mbps H.264.
- MP4 output folder: `game/recordings/livecraft/`.
- Disconnect and client shutdown request encoder finalization.

## Important limitations (read before testing)

1. **1440p60 is a target, not a guarantee.** The Android device's hardware encoder must accept 2560×1440 at 60 FPS and the phone must sustain the GPU readback and color conversion. On unsupported devices `/lcr start` fails and the reason is written to `latest.log`.
2. The current first milestone captures the rendered framebuffer using PBO readback and converts RGBA to flexible YUV420 on a worker thread. The color conversion is CPU-heavy at 1440p60. This is not yet the zero-copy EGL/Surface path, so it can lower game FPS and heat the phone. Test at a lower Minecraft render scale first.
3. The first milestone writes **video-only MP4**. Minecraft audio loopback is not implemented; Android playback capture requires extra permission/host integration and is a separate task.
4. The project does **not yet create ReplayMod-compatible `.mcpr` files**. `.mcpr` is a packet/world replay format, not an MP4 container. The current build milestone focuses on live MP4 recording rather than claiming a fake `.mcpr` file.
5. Automatic recording on world join is off by default. Use `/lcr start`; disconnect or closing Minecraft finalizes the MP4. A hard process kill, phone crash or power loss can still corrupt the last MP4.
6. The code has not been compiled or device-tested in this environment. Dependency resolution requires internet access and Gradle 9.2.1. Treat this as an alpha source project, not a production-ready JAR.

## Build

Use JDK 21 and Gradle 9.2.1 with internet access:

```sh
gradle build
```

The remapped mod JAR should be generated under `build/libs/`.

## Install

Copy the built JAR into the `mods` folder of an MJLauncher instance that runs Minecraft Java 1.21.11 with Fabric Loader and Fabric API. Back up worlds before testing any alpha mod.

## In game

```text
/lcr start
/lcr status
/lcr bitrate 24
/lcr stop
```

The bitrate command applies to the next recording. Output names use a timestamp to avoid overwriting existing recordings.

## Build without Termux (GitHub Actions)

1. In a browser, sign in to GitHub and create a **private** repository named `LiveCraftReplay`.
2. Upload the contents of this project ZIP to the repository (not the outer `LiveCraftReplay` folder). Make sure `.github/workflows/build.yml` is included. GitHub's web uploader may require adding the workflow file through **Add file → Create new file** if it hides dot-folders.
3. Open the repository's **Actions** tab. Select **Build Fabric mod** and press **Run workflow** (or push/upload to the `main` branch to trigger it).
4. Wait for the run to finish. If successful, open the run and download the `livecraft-replay-build` artifact. Extract it and find `livecraft-replay-0.1.0-alpha.jar` (the exact filename may include a Loom suffix).
5. Put the JAR in the `mods` folder for the MJLauncher instance running Minecraft Java 1.21.11 + Fabric. Keep a backup and test in a new world first.

This cloud build only compiles the source. It does not certify Android MediaCodec support or prove the mod works on the phone. Check the Actions log; if it fails, share the first error block so the source can be corrected. This process does not use or stop a Minecraft server or Termux.

## Full feature specification

See [FEATURES.md](FEATURES.md) for the complete agreed roadmap, defaults, and implementation milestones. The requested defaults are automatic recording on world join, optional microphone capture off by default, optional cloud backup off by default, and no artificial recording-duration cap. These are product requirements, not claims that the current alpha already implements them.

### Current controls (0.2.0-alpha development)
- F8: start recording (if not already recording)
- F7: pause/resume capture
- F9: stop and finalize MP4
- `/lcr start`, `/lcr pause`, `/lcr stop`, `/lcr status`

Automatic recording starts after joining a world when `autoStart` is enabled in `config/livecraft-replay.json`. The HUD displays `LCR ● REC` or `LCR PAUSED` while recording.

Note: these controls do not imply that the Android MediaCodec capture pipeline has been verified on every MJLauncher device. Pause currently omits frames during the paused interval; it does not stop the encoder process. A clickable pause-menu UI, audio, `.mcpr` replay capture, and media-library browser remain future work.
